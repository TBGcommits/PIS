import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useTranslation } from 'react-i18next';

const ProjectList = () => {
  const [projects, setProjects] = useState([]);
  const { t } = useTranslation();

  useEffect(() => {
    axios.get('/api/projects')
      .then(res => setProjects(res.data))
      .catch(() => setProjects([]));
  }, []);

  return (
    <div>
      <h3>{t('projects')}</h3>
      <table>
        <thead>
          <tr>
            <th>{t('project_name')}</th>
            <th>{t('client')}</th>
            <th>{t('budget')}</th>
            <th>{t('status')}</th>
          </tr>
        </thead>
        <tbody>
          {projects.map(proj => (
            <tr key={proj.projectId}>
              <td>{proj.projectName}</td>
              <td>{proj.client}</td>
              <td>{proj.budget}</td>
              <td>{t(proj.status.toLowerCase())}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ProjectList;