import React, { useState } from 'react';
import axios from 'axios';
import { useTranslation } from 'react-i18next';

const ProjectForm = ({ onProjectCreated }) => {
  const { t } = useTranslation();
  const [form, setForm] = useState({
    projectName: '',
    client: '',
    budget: '',
    startDate: '',
    endDate: '',
    status: 'Active'
  });

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    await axios.post('/api/projects', form);
    setForm({
      projectName: '',
      client: '',
      budget: '',
      startDate: '',
      endDate: '',
      status: 'Active'
    });
    if (onProjectCreated) onProjectCreated();
  };

  return (
    <form onSubmit={handleSubmit}>
      <h3>{t('add_project')}</h3>
      <input name="projectName" placeholder={t('project_name')} value={form.projectName} onChange={handleChange} required />
      <input name="client" placeholder={t('client')} value={form.client} onChange={handleChange} required />
      <input name="budget" type="number" placeholder={t('budget')} value={form.budget} onChange={handleChange} required />
      <input name="startDate" type="date" value={form.startDate} onChange={handleChange} required />
      <input name="endDate" type="date" value={form.endDate} onChange={handleChange} required />
      <select name="status" value={form.status} onChange={handleChange}>
        <option value="Active">{t('active')}</option>
        <option value="Completed">{t('completed')}</option>
        <option value="OnHold">{t('onhold')}</option>
      </select>
      <button type="submit">{t('add_project')}</button>
    </form>
  );
};

export default ProjectForm;