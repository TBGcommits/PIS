import React from "react";
import './i18n';
import LanguageSwitcher from "./components/LanguageSwitcher";
import ProjectList from "./components/ProjectList";
import ProjectForm from "./components/ProjectForm";
import { useTranslation } from "react-i18next";

function App() {
  const { t } = useTranslation();
  const [refresh, setRefresh] = React.useState(false);

  return (
    <div style={{ direction: document.dir, maxWidth: 800, margin: "0 auto" }}>
      <LanguageSwitcher />
      <h2>{t('welcome')}</h2>
      <ProjectForm onProjectCreated={() => setRefresh(!refresh)} />
      <ProjectList key={refresh} />
    </div>
  );
}

export default App;