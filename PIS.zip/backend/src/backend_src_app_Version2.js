const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
require('dotenv').config();

const sequelize = require('../config/db');
const projectRoutes = require('./routes/projects');
// يمكنك إضافة الراوترات الأخرى هنا

const app = express();

app.use(cors());
app.use(bodyParser.json());

app.use('/api/projects', projectRoutes);
// أضف الراوترات الأخرى هنا

app.get('/', (req, res) => {
  res.send('ConstructSmart Backend API is running!');
});

const PORT = process.env.PORT || 5000;

sequelize.sync().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
});