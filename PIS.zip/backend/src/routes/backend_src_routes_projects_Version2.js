const express = require('express');
const router = express.Router();
const Project = require('../models/Project');

// إضافة مشروع جديد
router.post('/', async (req, res) => {
  try {
    const project = await Project.create(req.body);
    res.status(201).json(project);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// جلب كل المشاريع
router.get('/', async (req, res) => {
  const projects = await Project.findAll();
  res.json(projects);
});

// جلب تفاصيل مشروع
router.get('/:id', async (req, res) => {
  const project = await Project.findByPk(req.params.id);
  if (!project) return res.status(404).send('Project not found');
  res.json(project);
});

module.exports = router;