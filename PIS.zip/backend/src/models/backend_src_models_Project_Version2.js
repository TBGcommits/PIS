const { DataTypes } = require('sequelize');
const sequelize = require('../../config/db');

const Project = sequelize.define('Project', {
  projectId: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  projectName: DataTypes.STRING,
  client: DataTypes.STRING,
  budget: DataTypes.FLOAT,
  startDate: DataTypes.DATE,
  endDate: DataTypes.DATE,
  status: DataTypes.ENUM('Active', 'Completed', 'OnHold'),
  contractDocumentUrl: DataTypes.TEXT
}, {
  timestamps: true,
  createdAt: 'createdAt',
  updatedAt: false
});

module.exports = Project;